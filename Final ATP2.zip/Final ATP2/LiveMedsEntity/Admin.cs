﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LiveMedsEntity
{
  
    public class Admin
    {

        public int AdminId { get; set; }
        public string AdminName { get; set; }
        public string AdminUserName { get; set; }
        public string AdminEmail { get; set; }
        public string AdminPassword { get; set; }


    }



}